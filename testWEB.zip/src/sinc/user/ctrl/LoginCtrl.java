package sinc.user.ctrl;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sinc.ctrl.util.Controller;
import sinc.ctrl.view.View;
import sinc.user.model.vo.UserVO;
import sinc.user.service.UserService;
import sinc.user.service.UserServiceImpl;

public class LoginCtrl implements Controller {

	private UserService service;

	public LoginCtrl() {
		service = new UserServiceImpl();
	}
	
	@Override
	public View execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("LoginCtrl execute");
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		UserVO user = new UserVO();
		user.setId(id);
		user.setPwd(pwd);
		UserVO result = (UserVO) service.login(user);
		System.out.println(result.toString());
		View view = new View();
		if (result != null) {
			view.setPath("index.sinc");
			view.setSend(false);
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", result);
		} else {
			view.setPath("error.jsp");
			view.setSend(true);
		}
		return view;
	}

}