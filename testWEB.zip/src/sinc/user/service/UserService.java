package sinc.user.service;

public interface UserService {

	public Object login(Object obj);
}
