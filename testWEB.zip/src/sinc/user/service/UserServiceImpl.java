package sinc.user.service;

import sinc.user.model.sql.UserDao;
import sinc.user.model.sql.UserDaoImpl;
import sinc.user.model.vo.UserVO;

public class UserServiceImpl implements UserService {

	private UserDao dao;

	public UserServiceImpl() {
		dao = new UserDaoImpl();
	}

	@Override
	public Object login(Object user) {
		// 패스워드 확인절차
		System.out.println("UserService Login");
		UserVO vo = (UserVO) dao.loginRow(user);
		return dao.loginRow(user);
	}

}