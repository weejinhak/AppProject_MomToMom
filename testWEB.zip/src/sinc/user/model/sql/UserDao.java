package sinc.user.model.sql;

public interface UserDao {

	public Object loginRow(Object obj);
}
