package sinc.user.model.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Vector;

import sinc.user.model.sql.UserDao;
import sinc.user.model.vo.UserVO;

public class UserDaoImpl implements UserDao {

	public static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String URL = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	public static final String USER = "hr";
	public static final String PASSWORD = "hr";

	public UserDaoImpl() {
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Object loginRow(Object obj) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		UserVO user = (UserVO) obj;
		String selectSQL = "SELECT ID, PWD, NAME, POINT, DEPT FROM FRM_USERS_TBL WHERE ID = ? AND PWD = ?";

		UserVO entity = null;

		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			pstmt = conn.prepareStatement(selectSQL);
			pstmt.setString(1, user.getId());
			pstmt.setString(2, user.getPwd());
			rset = pstmt.executeQuery();

			if (rset.next()) {
				entity = new UserVO(rset.getString(1), rset.getString(2), rset.getString(3), rset.getInt(4),
						rset.getString(5));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {

			}
		}

		return entity;
	}

}