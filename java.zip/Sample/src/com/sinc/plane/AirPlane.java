package com.sinc.plane;

public class AirPlane extends Plane{
	
	public AirPlane() {
		super();
	}

	public AirPlane(String planeName, int fuelSize) {
		super(planeName, fuelSize);
	}

	@Override
	public void flight(int distance) {		
		setFuelSize(getFuelSize() - distance*3); 
	}

}
