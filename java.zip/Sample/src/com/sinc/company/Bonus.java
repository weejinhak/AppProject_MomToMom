package com.sinc.company;

public interface Bonus {
	
	public void incentive(int pay);
	
}
