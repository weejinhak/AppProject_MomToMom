package com.sinc.cafe;

public class Cafe {

	private Coffee[] coffeeList;
	private int index;
	
	
	public Cafe() {
		super();
	}


	public Coffee[] getCoffeeList() {
		return coffeeList;
	}


	public void setCoffeeList(Coffee[] coffeeList) {
		this.coffeeList = coffeeList;
	}


	public int getIndex() {
		return index;
	}


	public void setIndex(int index) {
		this.index = index;
	}
	
	
	
	
}
