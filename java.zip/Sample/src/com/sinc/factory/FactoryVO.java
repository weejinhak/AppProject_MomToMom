package com.sinc.factory;

public class FactoryVO {

	private String factno;
	private String facname;
	private String facloc;
	public FactoryVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FactoryVO(String factno, String facname, String facloc) {
		super();
		this.factno = factno;
		this.facname = facname;
		this.facloc = facloc;
	}
	public String getFactno() {
		return factno;
	}
	public void setFactno(String factno) {
		this.factno = factno;
	}
	public String getFacname() {
		return facname;
	}
	public void setFacname(String facname) {
		this.facname = facname;
	}
	public String getFacloc() {
		return facloc;
	}
	public void setFacloc(String facloc) {
		this.facloc = facloc;
	}
	@Override
	public String toString() {
		return factno + "\t\t" + facname + "\t\t" + facloc;
	}
	
}
