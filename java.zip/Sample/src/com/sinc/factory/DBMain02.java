package com.sinc.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBMain02 {

	public static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String URL = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	public static final String USER = "hr";
	public static final String PASSWORD = "hr";

	public static void main(String[] args) {

		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;

		String selectSQL = "SELECT 	B.PDSUBNAME, B.PDCOST, B.PDPRICE\r\n" + 
				"FROM\r\n" + 
				"		(\r\n" + 
				"			SELECT CASE \r\n" + 
				"						WHEN (SELECT MIN(PDCOST) AS LOWVAL FROM PRODUCT WHERE PDNAME = 'TV' ) < PDCOST\r\n" + 
				"						THEN\r\n" + 
				"							CASE\r\n" + 
				"								WHEN	(SELECT MAX(PDCOST) AS MAXVAL FROM PRODUCT WHERE PDNAME = 'CELLPHONE') > PDCOST\r\n" + 
				"								THEN PDNO\r\n" + 
				"							END\r\n" + 
				"					END\r\n" + 
				"				AS PDNO\r\n" + 
				"			FROM PRODUCT\r\n" + 
				"		) A, PRODUCT B\r\n" + 
				"WHERE A.PDNO = B.PDNO";
		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			pstmt = conn.prepareStatement(selectSQL);
//			pstmt.setString(1, "SEOUL");
			// pstmt.setString(2, sta);

			rset = pstmt.executeQuery();

			System.out.println("제품명\t\t제품원가\t\t제품가격");
			System.out.println(
					"-----------------------------------------------------------------------------------------");
			while (rset.next()) {
				System.out.println(rset.getString(1) + "\t\t" + rset.getString(2) + "\t\t" + rset.getString(3));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {

			}
		}
	}

}
