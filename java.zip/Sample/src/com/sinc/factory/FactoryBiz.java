package com.sinc.factory;

import java.util.List;

public class FactoryBiz {

	private FactoryDAO dao;

	public FactoryBiz() {
		super();
	}
	
	public List<Object> getFactoryAll(){
		dao = new FactoryDAO();
		//biz로직
		return dao.getFactoryAll();
	}
	
}
