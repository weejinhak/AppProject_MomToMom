package com.sinc.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Vector;

public class FactoryDAO {

	public static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String URL = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	public static final String USER = "hr";
	public static final String PASSWORD = "hr";

	public FactoryDAO() {
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public List<Object> getFactoryAll() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		List<Object> vec = new Vector<Object>();
		
		String selectSQL = "SELECT FACTNO, FACNAME, FACLOC FROM FACTORY";

		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			pstmt = conn.prepareStatement(selectSQL);

			rset = pstmt.executeQuery();

			while (rset.next()) {
				FactoryVO entity = new FactoryVO(rset.getString(1), rset.getString(2), rset.getString(3));
				vec.add(entity);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {

			}
		}

		return vec;
	}
	
}
