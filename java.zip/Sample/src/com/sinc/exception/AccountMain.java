package com.sinc.exception;

public class AccountMain {

	public static void main(String[] args) {

		Account account = new Account("411-0290-1203", 500000, 7.3);

		System.out.println(account.toString());

		try {
			account.deposit(-10);
		} catch (Exception e) {
		}

		try {
			account.withdraw(600000);
		} catch (Exception e) {
			System.out.println("금액이 0보다 적거나 현재 잔액보다 많습니다.");
		}

		System.out.println("이자:\t" + account.calculateInterest());

	}

}
