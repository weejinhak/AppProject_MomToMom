package com.sinc.human;

public class HumanMain {

	public static void main(String[] args) {
		
		Human[] hAry = new Human[3];
		hAry[0] = new Student("홍길동", 15, 171, 81, "201101", "영문");
		hAry[1] = new Student("한사람", 13, 183, 72, "201102", "건축");
		hAry[2] = new Student("임걱정", 16, 175, 65, "201103", "무용");
		
		printInform(hAry);
		
	}

	private static void printInform(Human[] hAry) {
		for(Human h : hAry) {
			//메소드가 오버라이드 되어있어서 안해도 상관없지만 혹시 몰라서 함
			if (h instanceof Student) {
				System.out.println(((Student)h).printInformation());				
			}
		}		
	}
}
