package om.sinc.mobile;

public class MobileMain {

	public static void main(String[] args) {
		
		Mobile[] mAry = new Mobile[2];
		mAry[0] = new Ltab("Ltab", 500, "AP-01");
		mAry[1] = new Otab("Otab", 1000, "AND-20");
		
		System.out.println("Mobile\t\tBattery\t\tOS");
		System.out.println("--------------------------------------");
		System.out.println(mAry[0].toString());
		System.out.println(mAry[1].toString());
		
		System.out.println();
		System.out.println("10분충전");
		mAry[0].charge(10);
		mAry[1].charge(10);
		System.out.println("Mobile\t\tBattery\t\tOS");
		System.out.println("--------------------------------------");
		System.out.println(mAry[0].toString());
		System.out.println(mAry[1].toString());

		System.out.println();
		System.out.println("5분통화");
		mAry[0].operate(5);
		mAry[1].operate(5);
		System.out.println("Mobile\t\tBattery\t\tOS");
		System.out.println("--------------------------------------");
		System.out.println(mAry[0].toString());
		System.out.println(mAry[1].toString());
		
		
		
	}

}
