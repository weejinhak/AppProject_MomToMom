package com.sinc.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBMain01 {

	public static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String URL = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	public static final String USER = "hr";
	public static final String PASSWORD = "hr";

	public static void main(String[] args) {

		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;

		String selectSQL = "SELECT PDNAME, PDSUBNAME, FACNAME, STONAME, STAMOUNT FROM PRODUCT P, FACTORY F, STORE S "
				+ "WHERE P.FACTNO = F.FACTNO AND P.PDNO = S.PDNO AND F.FACNAME LIKE '%SEOUL%' AND (S.STAMOUNT IS NULL OR S.STAMOUNT = 0)";
		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			pstmt = conn.prepareStatement(selectSQL);
//			pstmt.setString(1, "SEOUL");
			// pstmt.setString(2, sta);

			rset = pstmt.executeQuery();

			System.out.println("제품카테고리\t\t제품명\t\t공장명\t\t판매점명\t\t판매점재고수량");
			System.out.println(
					"-----------------------------------------------------------------------------------------");
			while (rset.next()) {
				System.out.println(rset.getString(1) + "\t\t" + rset.getString(2) + "\t\t" + rset.getString(3) + "\t\t"
						+ rset.getString(4) + "\t\t" + rset.getInt(5));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {

			}
		}
	}

}
