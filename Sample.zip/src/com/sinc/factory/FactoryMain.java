package com.sinc.factory;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class FactoryMain {

	public static void main(String[] args) {
		
		FactoryBiz fb = new FactoryBiz();
		
		List<Object> l = new Vector<Object>();
		l = fb.getFactoryAll();

		System.out.println("공장번호\t\t공장명\t\t공장위치");
		System.out.println("------------------------------------------------");
		Iterator<Object> ite = l.iterator();
		while(ite.hasNext()) {
			System.out.println(ite.next());
		}
	}

}
