package com.sinc.cafe;

public class CafeMain {

	public static void main(String[] args) {
		
		Cafe cafe = new Cafe();
		
		Coffee[] cAry = new Coffee[3];
		cAry[0] = new Coffee("Americano", 4000);
		cAry[1] = new Coffee("Caffelatte", 5000);
		cAry[2] = new Coffee("Macchiato", 6000);		
		
		cafe.setCoffeeList(cAry);
		
		printInform(cAry);
		
	}

	private static void printInform(Coffee[] cAry) {
		for(Coffee c : cAry) {
			System.out.println(c.toString());
		}
		
	}

}
