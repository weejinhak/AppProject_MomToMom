package com.sinc.plane;

public class PlaneMain {

	public static void main(String[] args) {
		
		Plane[] pAry = new Plane[2];
		pAry[0] = new AirPlane("L747", 1000);
		pAry[1] = new CargoPlane("C40", 1000);		

		System.out.println("Plane\t\tfuelSize");
		System.out.println("----------------------------");
		System.out.println(pAry[0].toString());
		System.out.println(pAry[1].toString());


		System.out.println();
		System.out.println("100 운항");
		pAry[0].flight(100);
		pAry[1].flight(100);
		System.out.println("Plane\t\tfuelSize");
		System.out.println("----------------------------");
		System.out.println(pAry[0].toString());
		System.out.println(pAry[1].toString());
		
		
		System.out.println();
		System.out.println("200 주유");
		pAry[0].refuel(200);
		pAry[1].refuel(200);
		System.out.println("Plane\t\tfuelSize");
		System.out.println("----------------------------");
		System.out.println(pAry[0].toString());
		System.out.println(pAry[1].toString());
	}

}
